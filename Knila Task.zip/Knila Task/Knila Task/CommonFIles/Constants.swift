//
//  Constants.swift
//  TripTruly
//
//  Created by APPLE on 19/11/18.
//  Copyright © 2018 APPLE. All rights reserved.
//

import UIKit


struct WebServicesUrl{
 
    static let GetData = "https://reqres.in/api/users"
    
}


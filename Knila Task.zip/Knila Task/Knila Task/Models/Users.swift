//
//  Users.swift
//  Knila Task
//
//  Created by RekhaSuresh on 03/02/21.
//  Copyright © 2021 RekhaTesting app. All rights reserved.
//

import UIKit

struct usersStruct: Codable {
   var data: [user]
}
struct user : Codable {
    var id: String?
    var email: String?
    var first_name: String?
    var last_name: String?
    var avatar: String?
}

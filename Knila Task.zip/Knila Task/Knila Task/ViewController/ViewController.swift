//
//  ViewController.swift
//  Knila Task
//
//  Created by RekhaSuresh on 03/02/21.
//  Copyright © 2021 RekhaTesting app. All rights reserved.
//

import UIKit
import Alamofire
import SDWebImage
import CoreData

var usersArrGlobal = [user]()


class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    var nameArray = [String]()
    var emailArray = [String]()
    var idArray = [String]()
    var imageArray = [String]()
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
     fetchData()
    }
   override func viewWillAppear(_ animated: Bool) {
    if nameArray.count>0 {
        fetchData()
    }else {
         getAPIData()
    }
    }
    func fetchData()
    {
        print("Fetching Data..")
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "UsersDetails")
        request.returnsObjectsAsFaults = false
        do {
            let result = try context.fetch(request)
            for data in result as! [NSManagedObject] {
                let id = data.value(forKey: "id") as? String ?? ""
                let avatar = data.value(forKey: "avatar") as? String ?? ""
                let firstName = data.value(forKey: "firstName") as? String ?? ""
                let lastName = data.value(forKey: "lastName") as? String ?? ""
                let email = data.value(forKey: "email") as? String ?? ""
                if !emailArray .contains(email) {
                    nameArray .append("\(firstName)\(lastName)")
                    imageArray .append(avatar)
                    emailArray .append(email)
                    idArray .append(id)
                }
               
            }

            self.tableView.delegate = self
            self.tableView.dataSource = self
            self.tableView .reloadData()
        } catch {
            print("Fetching data Failed")
        }
    }
    
    func getAPIData() {
        let url = URL(string: WebServicesUrl.GetData)!
        AF.request(url, method: .get, encoding: JSONEncoding.default)
            .responseJSON { response in
                switch response.result {
                case .success(let json):
                    print(json)
                    DispatchQueue.main.async {
                        self.parseData(JSONData: response.data!)
                    }
                case .failure(let error):
                    print(error)
                }
        }
    }
    func parseData(JSONData: Data) {
        do {
            let readableJSON = try JSONSerialization.jsonObject(with: JSONData, options:.allowFragments) as! [String: AnyObject]
            print(readableJSON)
            let featureProductArr = readableJSON["data"] as! [[String:AnyObject]]
            
            for aUsersDict in featureProductArr
            {
                var aUsersStruct = user()
                aUsersStruct.id = "\(aUsersDict["id"]!)"
                aUsersStruct.avatar = "\(aUsersDict["avatar"]!)"
                aUsersStruct.first_name = "\(aUsersDict["first_name"]!)"
                aUsersStruct.last_name = "\(aUsersDict["last_name"]!)"
                aUsersStruct.email = "\(aUsersDict["email"]!)"
                self.saveIntoCoreData(id: aUsersStruct.id!, avatar: aUsersStruct.avatar!, email: aUsersStruct.email!, firstName: aUsersStruct.first_name!, lastName: aUsersStruct.last_name!)
                usersArrGlobal.append(aUsersStruct)
            }
         
        } catch { print("hello",error) }
    }
    func saveIntoCoreData(id: String, avatar: String, email: String, firstName: String, lastName: String)  {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        let registerObject = NSEntityDescription.insertNewObject(forEntityName: "UsersDetails", into: context)
        
        registerObject.setValue(id, forKey: "id")
        registerObject.setValue(avatar, forKey: "avatar")
        registerObject.setValue(email, forKey: "email")
        registerObject.setValue(firstName, forKey: "firstName")
        registerObject.setValue(lastName, forKey: "lastName")
        
        do
        {
            try context.save()
            fetchData()
            print("saved")
        }
        catch
        {
            print("error while saving")
        }
    }
    
    //MARK - Tableview Delegate and Data Source
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return nameArray.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 125.0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")!
        cell.layer.cornerRadius = 05
        let avatar = cell.contentView.viewWithTag(1) as! UIImageView
        let name = cell.contentView.viewWithTag(2) as! UILabel
        let email = cell.contentView.viewWithTag(3) as! UILabel
        let id = cell.contentView.viewWithTag(4) as! UILabel
        
        let mainView = cell.contentView.viewWithTag(5)!
        mainView.layer.cornerRadius = 5.0
        avatar.sd_setImage(with: URL(string: imageArray[indexPath.row]), placeholderImage: UIImage(named: "placeholder.png"))
        name.text = nameArray[indexPath.row]
        email.text = emailArray[indexPath.row]
        id.text = idArray[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        
        let editAction = UITableViewRowAction(style: .normal, title: "Edit") { (rowAction, indexPath) in
            //TODO: edit the row at indexPath here
            let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "AddNewUserVC") as? AddNewUserViewController
            vc!.name = self.nameArray[indexPath.row]
            vc!.email = self.emailArray[indexPath.row]
            vc!.avatar = self.imageArray[indexPath.row]
            vc!.id = self.idArray[indexPath.row]
            
            self.navigationController?.pushViewController(vc!, animated: true)
        }
        editAction.backgroundColor = .blue
        
        let deleteAction = UITableViewRowAction(style: .normal, title: "Delete") { (rowAction, indexPath) in
            //TODO: Delete the row at indexPath here
            self.nameArray.remove(at: indexPath.row)
            self.emailArray.remove(at: indexPath.row)
            self.imageArray.remove(at: indexPath.row)
            self.idArray.remove(at: indexPath.row)
            tableView.reloadData()
        }
        deleteAction.backgroundColor = .red
        
        return [editAction,deleteAction]
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "DetailsVC") as? DetailsViewController
        vc!.name = nameArray[indexPath.row]
        vc!.email = emailArray[indexPath.row]
        vc!.avatar = imageArray[indexPath.row]
        vc!.id = idArray[indexPath.row]
        
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}

extension UIImage {
    convenience init?(url: URL?) {
        guard let url = url else { return nil }
        
        do {
            self.init(data: try Data(contentsOf: url))
        } catch {
            print("Cannot load image from url: \(url) with error: \(error)")
            return nil
        }
    }
}

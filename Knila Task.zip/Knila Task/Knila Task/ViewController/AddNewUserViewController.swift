//
//  AddNewUserViewController.swift
//  Knila Task
//
//  Created by RekhaSuresh on 03/02/21.
//  Copyright © 2021 RekhaTesting app. All rights reserved.
//

import UIKit
import CoreData

class AddNewUserViewController: UIViewController , UINavigationControllerDelegate, UIImagePickerControllerDelegate, UITextFieldDelegate {

    @IBOutlet var imageView: UIImageView!
    @IBOutlet var chooseBuuton: UIButton!
    var imagePicker: UIImagePickerController!
       enum ImageSource {
           case photoLibrary
           case camera
       }

    var name, avatar, email, id : String?
  
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var firstNameTxtField: UITextField!
       @IBOutlet weak var lastNameTxtField: UITextField!
       @IBOutlet weak var emailTxtField: UITextField!
       @IBOutlet weak var idTxtField: UITextField!
       
    override func viewDidLoad() {
           super.viewDidLoad()
     
        firstNameTxtField.delegate = self
        lastNameTxtField.delegate = self
        emailTxtField.delegate = self
        idTxtField.delegate = self
        
           NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
           NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    // MARK - Keyboard notification
    @objc func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
            if self.mainView.frame.origin.y == 0 {
                self.mainView.frame.origin.y -= keyboardSize.height
            }
        }
    }
    @objc func keyboardWillHide(notification: NSNotification) {
        if self.mainView.frame.origin.y != 0 {
            self.mainView.frame.origin.y = 0
        }
    }
    
    // MARK: UITextFieldDelegate methods
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    
    @IBAction func saveBtnClicked(_ sender: UIButton) {
        if self.imageView.image == nil {
             String().alert(view: self, title: "Knila Info", message: "Please select profile image")
        }else if self.firstNameTxtField.text == "" {
             String().alert(view: self, title: "Knila Info", message: "Enter first name")
        }else if self.lastNameTxtField.text == "" {
             String().alert(view: self, title: "Knila Info", message: "Enter last name")
        }else if self.emailTxtField.text == "" {
             String().alert(view: self, title: "Knila Info", message: "Enter email id")
        }else if self.idTxtField.text == "" {
             String().alert(view: self, title: "Knila Info", message: "Enter user id")
        }else {
            String().alert(view: self, title: "Knila Info", message: "Registration successfully")
            
            let imageData: Data? = imageView.image!.jpegData(compressionQuality: 0.4)
            let imageStr = imageData?.base64EncodedString(options: .lineLength64Characters) ?? ""
            print(imageStr)
            
            self.saveIntoCoreData(id: idTxtField.text!, avatar: imageStr, email: emailTxtField.text!, firstName: firstNameTxtField.text!, lastName: lastNameTxtField.text!)
        }
    }
    func saveIntoCoreData(id: String, avatar: String, email: String, firstName: String, lastName: String)  {
              let appDelegate = UIApplication.shared.delegate as! AppDelegate
              let context = appDelegate.persistentContainer.viewContext
              let registerObject = NSEntityDescription.insertNewObject(forEntityName: "UsersDetails", into: context)
              
              registerObject.setValue(id, forKey: "id")
              registerObject.setValue(avatar, forKey: "avatar")
              registerObject.setValue(email, forKey: "email")
              registerObject.setValue(firstName, forKey: "firstName")
              registerObject.setValue(lastName, forKey: "lastName")
       
              do
              {
                  try context.save()
                  print("saved")
              }
              catch
              {
               print("error while saving")
              }
          }
    @IBAction func btnClicked() {
//       guard UIImagePickerController.isSourceTypeAvailable(.camera) else {
//                    selectImageFrom(.photoLibrary)
//                    return
//                }
                selectImageFrom(.photoLibrary)
            }

            func selectImageFrom(_ source: ImageSource){
                imagePicker =  UIImagePickerController()
                imagePicker.delegate = self
                switch source {
                case .camera:
                    imagePicker.sourceType = .camera
                case .photoLibrary:
                    imagePicker.sourceType = .photoLibrary
                }
                present(imagePicker, animated: true, completion: nil)
            }

            //MARK: - Saving Image here
            @IBAction func save(_ sender: AnyObject) {
                guard let selectedImage = imageView.image else {
                    print("Image not found!")
                    return
                }
                UIImageWriteToSavedPhotosAlbum(selectedImage, self, #selector(image(_:didFinishSavingWithError:contextInfo:)), nil)
            }

            //MARK: - Add image to Library
            @objc func image(_ image: UIImage, didFinishSavingWithError error: Error?, contextInfo: UnsafeRawPointer) {
                if let error = error {
                    // we got back an error!
                    showAlertWith(title: "Save error", message: error.localizedDescription)
                } else {
                    showAlertWith(title: "Saved!", message: "Your image has been saved to your photos.")
                }
            }

            func showAlertWith(title: String, message: String){
                let ac = UIAlertController(title: title, message: message, preferredStyle: .alert)
                ac.addAction(UIAlertAction(title: "OK", style: .default))
                present(ac, animated: true)
            }
      
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]){
        imagePicker.dismiss(animated: true, completion: nil)
        guard let selectedImage = info[.originalImage] as? UIImage else {
            print("Image not found!")
            return
        }
        imageView.image = selectedImage
    }
    
  
    
}

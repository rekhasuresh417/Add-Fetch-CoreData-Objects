//
//  DetailsViewController.swift
//  Knila Task
//
//  Created by RekhaSuresh on 03/02/21.
//  Copyright © 2021 RekhaTesting app. All rights reserved.
//

import UIKit
import SDWebImage

class DetailsViewController: UIViewController {

    var name, avatar, email, id : String?
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var idLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        imageView.sd_setImage(with: URL(string: avatar!), placeholderImage: UIImage(named: "placeholder.png"))
        nameLabel.text = "Name : \(name!) "
        emailLabel.text = "Email Id : \(email!) "
        idLabel.text = "User Id : \(id!) "
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
